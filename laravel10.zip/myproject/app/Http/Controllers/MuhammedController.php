<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MuhammedController extends Controller
{
     public function index(){
        return view('muhammed.index');
     }

     public function show(){
        return view('muhammed.show');
     }
     public function edit(){
        return view('muhammed.edit');
     }
     public function create(){
        return view('muhammed.create');
     }
}
