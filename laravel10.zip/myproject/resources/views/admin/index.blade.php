<h1>Admin panel</h1>


<h1>{{$name}}</h1>