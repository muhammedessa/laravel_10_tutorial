<h1>Create User</h1>

<h1>{{$name1}}</h1>
<h1>{{$name2}}</h1>

The current UNIX timestamp is {{ time() }}.


Hello, {!! $name !!}.


@if ($name == 'Muhammed')
     <h1>Muhammed</h1>
@elseif ($name == 'Omer')
       <h1>Omer</h1>
@else
     <h1>{{$name }}</h1>
@endif

<br>
@unless (Auth::check())
    You are not signed in.
@endunless

<br>
@isset($name)
    // {{$name}} is defined and is not null...
@endisset
<br>
@empty($name)
    // {{$name}} is "empty"...
@endempty


@auth
     The user is authenticated...
@endauth
 
@guest
     The user is not authenticated...
@endguest