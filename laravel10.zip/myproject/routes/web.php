<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;

use App\Http\Controllers\MuhammedController;
use App\Http\Controllers\EssaController;
 


Route::get('/muhammed/test/index', [MuhammedController::class, 'index']);
Route::get('/muhammed/test/show', [MuhammedController::class, 'show']);
Route::get('/muhammed/test/edit', [MuhammedController::class, 'edit']);
Route::get('/muhammed/test/create', [MuhammedController::class, 'create']);

Route::get('/essa/test/index', [EssaController::class, 'index']);
Route::get('/essa/test/show', [EssaController::class, 'show']);
Route::get('/essa/test/edit', [EssaController::class, 'edit']);
Route::get('/essa/test/create', [EssaController::class, 'create']);








Route::get('/', function () {
    return view('welcome');
});

Route::get('/test', function(){
    return '<h1>Muhammed Essa</h1>';
});


Route::get('/muhammed', function(){
    return redirect()->route('essa');
});

Route::get('/user/admin/essa', function(){
    return '<h1> Essa</h1>';
})->name('essa');


// Route::view('/users', 'users');

Route::view('/users', 'users', ['name' => 'Muhammed Essa']);


Route::get('/users/{id}', function (string $id) {
    return 'User '.$id;
});

Route::get('/posts/{post}/comments/{comment}', function (string $postId, string $commentId) {
    return 'post id '.$postId. ' comment id '.$commentId;
})->name('postcomment');


Route::get('/user/{name?}', function (string $name = 'John') {
    return $name;
});


// Route::get('/muhammed/essa',function(){
//     return view('muhammed', ['name'=> 'This is Muhammed Essa']);
// });

Route::view('/muhammed/essa', 'muhammed', ['name' => 'Muhammed Essa']);


Route::get('/admin/panel',function(){
    return view('admin.index', ['name'=> 'Welcome Admin']);
});

Route::view('/muhammed/panel', 'users.index', ['name' => 'Welcome User']);


Route::get('/post/panel',function(){
    return View::first(['users.user', 'admin.index'] , ['name'=> 'Welcome Admin']);
});


Route::get('/create/user',function(){
    return view('users.create')
                   ->with('name1','Essa')
                   ->with('name','Ali')
                   ->with('name2','Hameed');
});