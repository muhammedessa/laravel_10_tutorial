<h1>Admin panel</h1>


<h1><?php echo e($name); ?></h1><?php /**PATH /Users/muhammed/Desktop/myproject/resources/views/admin/index.blade.php ENDPATH**/ ?>