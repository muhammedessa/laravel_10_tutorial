<h1>Create User</h1>

<h1><?php echo e($name1); ?></h1>
<h1><?php echo e($name2); ?></h1>

The current UNIX timestamp is <?php echo e(time()); ?>.


Hello, <?php echo $name; ?>.


<?php if($name == 'Muhammed'): ?>
     <h1>Muhammed</h1>
<?php elseif($name == 'Omer'): ?>
       <h1>Omer</h1>
<?php else: ?>
     <h1><?php echo e($name); ?></h1>
<?php endif; ?>

<br>
<?php if (! (Auth::check())): ?>
    You are not signed in.
<?php endif; ?>

<br>
<?php if(isset($name)): ?>
    // <?php echo e($name); ?> is defined and is not null...
<?php endif; ?>
<br>
<?php if(empty($name)): ?>
    // <?php echo e($name); ?> is "empty"...
<?php endif; ?>


<?php if(auth()->guard()->check()): ?>
     The user is authenticated...
<?php endif; ?>
 
<?php if(auth()->guard()->guest()): ?>
     The user is not authenticated...
<?php endif; ?><?php /**PATH /Users/muhammed/Desktop/myproject/resources/views/users/create.blade.php ENDPATH**/ ?>