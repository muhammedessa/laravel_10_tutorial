<?php $__env->startSection('content'); ?>


<br>
<div class="row">
    <div class="col align-self-start">
     <a   class="btn btn-primary" href="<?php echo e(route('products.index')); ?>" >All products</a>
    </div>
     
  </div>
  <br>

 


<div class='container p-5'>


 

<div class="mb-3">
   
  <h3>Name : <?php echo e($product->name); ?></h3>  
 </div>
 <div class="mb-3">
   <p><?php echo e($product->details); ?></p>
 </div>
 <div class="mb-3">
    <img src="/images/<?php echo e($product->image); ?>" width="300px">
    
    </div>

  

 
   

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muhammed/Desktop/products-app/resources/views/products/show.blade.php ENDPATH**/ ?>