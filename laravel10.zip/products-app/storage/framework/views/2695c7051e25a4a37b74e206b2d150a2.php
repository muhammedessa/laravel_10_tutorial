<?php $__env->startSection('content'); ?>
<br>
 
  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success" role="alert">
   <?php echo e($message); ?>

  </div>
  <?php endif; ?>


  
<div class="table-responsive">
    <table class="table table-striped table-hover table-borderless table-primary align-middle">
        <thead class="table-light">
           
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Details</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-primary" >
                    <td><?php echo e($item->id); ?></td>
                    <td><img src="/images/<?php echo e($item->image); ?>" width="300px"></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->details); ?></td>
                    <td>
                        <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('products.destroy',$item->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                             </form>
                             <a class="btn btn-primary" href="<?php echo e(route('products.edit',$item->id)); ?>">Edit</a>  
                        <?php endif; ?>
                   
                    
                    
                    <a class="btn btn-info" href="<?php echo e(route('products.show',$item->id)); ?>">Show</a>     
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                
            </tbody>
            <tfoot>
                
            </tfoot>
    </table>

    <?php echo $products->links(); ?>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muhammed/Desktop/products-app/resources/views/products/index.blade.php ENDPATH**/ ?>