<?php $__env->startSection('content'); ?>


<br>
<div class="row">
    <div class="col align-self-start">
     <a   class="btn btn-primary" href="<?php echo e(route('products.index')); ?>" >All products</a>
    </div>
     
  </div>
  <br>


  <?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </ul>
  </div>
      
  <?php endif; ?>


<div class='container p-5'>


<form action="<?php echo e(route('products.update',$product->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="mb-3">
  <label for="" class="form-label">Name</label>
  <input type="text" class="form-control" name="name" value="<?php echo e($product->name); ?>" >
 </div>
 <div class="mb-3">
   <label for="" class="form-label">Details</label>
   <textarea class="form-control" name="details" id="" rows="3">
    <?php echo e($product->details); ?>

   </textarea>
 </div>
 <div class="mb-3">
    <img src="/images/<?php echo e($product->image); ?>" width="300px">
    
    <input type="file" class="form-control" name="image" >
   </div>

   <button type="submit" class="btn btn-primary">Submit</button>
 

</form>
   

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muhammed/Desktop/products-app/resources/views/products/edit.blade.php ENDPATH**/ ?>