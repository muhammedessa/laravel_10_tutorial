<?php $__env->startSection('content'); ?>


<br>
<div class="row">
    <div class="col align-self-start">
     <a   class="btn btn-primary" href="<?php echo e(route('products.index')); ?>" >All products</a>
    </div>
     
  </div>
  <br>


  <?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </ul>
  </div>
      
  <?php endif; ?>


<div class='container p-5'>


<form action="<?php echo e(route('products.store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<div class="mb-3">
  <label for="" class="form-label">Name</label>
  <input type="text" class="form-control" name="name" >
 </div>
 <div class="mb-3">
   <label for="" class="form-label">Details</label>
   <textarea class="form-control" name="details" id="" rows="3"></textarea>
 </div>
 <div class="mb-3">
    <label for="" class="form-label">Image</label>
    <input type="file" class="form-control" name="image" >
   </div>

   <button type="submit" class="btn btn-primary">Submit</button>
 

</form>
   

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muhammed/Desktop/products-app/resources/views/products/create.blade.php ENDPATH**/ ?>